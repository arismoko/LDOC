You are implementing LDOC v3 according to the repository docs.

MANDATORY: At the start of EVERY iteration, open and read these files completely:

- COMMITS.MD
- LDOC-V3-SPEC.md
- YAGNI.md
- LSP.md
- RALPH.md

Rules (KISS/YAGNI):

- Implement ONLY what is required by LDOC-V3-SPEC.md and the next item in COMMITS.MD.
- Avoid bonus scope, but do not use hacks that will obviously be torn out next commit.
- Make the smallest _correct and maintainable_ change that satisfies the current commit and keeps the repo ready for the next commit.

Work loop:

1. Pick the next unfinished commit from COMMITS.MD (in order).
2. Implement exactly that commit’s scope.
3. Run the project’s tests / smoke build. Fix only what you broke.
4. Commit changes with the commit message specified in COMMITS.MD.
5. Update COMMITS.MD to mark that commit done.

If blocked:

- Write a short BLOCKED note in RALPH.md (what you tried, the error, and the smallest next step).
- Do NOT output the completion promise.

Only when all commits in COMMITS.MD are completed and tests pass, output:
<promise>COMPLETE</promise>
