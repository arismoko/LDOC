/**
 * Block Emission
 *
 * Converts SemanticNode tree to LDOC block syntax:
 * - Headings: # H1, ## H2, @h1/@h2 blocks for multi-line
 * - Lists: - item, 1. item
 * - Paragraphs: plain text with inline formatting
 * - Groups: @style(spacing/align), @indent blocks
 * - Anchors: @anchor(name)
 */

import type {
  SemanticNode,
  SemanticParagraph,
  SemanticGroup,
  SpacingGroupAttrs,
  AlignmentGroupAttrs,
  IndentGroupAttrs,
} from "../semantic/types";
import { isParagraph, isTable, isGroup } from "../semantic/types";
import type { EmissionContext } from "./types";
import { indentContext } from "./types";
import { emitInlineContent } from "./inline";
import { emitTable } from "./table";
import { formatTwipsAsPt } from "../../shared/units";

/**
 * Format style attributes for @style directive.
 */
function formatStyleAttrs(
  attrs: Record<string, string>,
  spacing?: { spacingAfter?: number; spacingBefore?: number },
): string {
  const identRe = /^[A-Za-z_][A-Za-z0-9_-]*$/;
  const isNumber = (v: string) => /^(?:\d+(?:\.\d+)?|\.\d+)$/.test(v);
  const isLength = (v: string) => /^(?:\d+(?:\.\d+)?|\.\d+)(?:in|pt|cm|mm|twip)$/i.test(v);

  const formatValue = (v: string) => {
    if (v === "true" || v === "false") return v;
    if (isNumber(v) || isLength(v) || identRe.test(v)) return v;
    return JSON.stringify(v);
  };

  const parts: string[] = [];
  for (const [k, v] of Object.entries(attrs)) {
    if (v === "true") {
      parts.push(k);
    } else {
      parts.push(`${k}: ${formatValue(v)}`);
    }
  }

  if (spacing?.spacingAfter !== undefined) {
    parts.push(`spacing-after: ${spacing.spacingAfter}`);
  }
  if (spacing?.spacingBefore !== undefined) {
    parts.push(`spacing-before: ${spacing.spacingBefore}`);
  }

  return parts.join(", ");
}

/**
 * Emit anchors (bookmarks) as @anchor directives.
 */
function emitAnchors(anchors: string[], ctx: EmissionContext): string[] {
  return anchors.map((name) => `${ctx.indent}@anchor(${name})`);
}

/**
 * Emit a heading.
 */
function emitHeading(para: SemanticParagraph, ctx: EmissionContext): string[] {
  const lines: string[] = [];

  // Emit anchors first
  lines.push(...emitAnchors(para.anchors, ctx));

  const level = para.headingLevel ?? 1;
  const content = emitInlineContent(para.extracted.content, ctx);

  // Check for multi-line content
  if (content.includes("\n")) {
    // Multi-line heading: use @h1 block syntax
    lines.push(`${ctx.indent}@h${level}`);
    const childCtx = indentContext(ctx);
    for (const line of content.split("\n")) {
      lines.push(`${childCtx.indent}${line}`);
    }
  } else {
    // Single-line heading: use # syntax
    const hashes = "#".repeat(Math.max(1, Math.min(6, level)));
    lines.push(`${ctx.indent}${hashes} ${content}`);
  }

  return lines;
}

/**
 * Emit a list item.
 * If the list item has a named style (e.g. LegalList), wraps in @style(style: X).
 */
function emitListItem(para: SemanticParagraph, ctx: EmissionContext): string[] {
  const lines: string[] = [];

  // Emit anchors first
  lines.push(...emitAnchors(para.anchors, ctx));

  const prefix = para.listPrefix ?? "- ";
  const content = emitInlineContent(para.extracted.content, ctx);

  // Check for named style that needs to be preserved
  const styleId = para.extracted.styleId;
  const needsStyleName = styleId && !isStructuralStyle(styleId);

  if (needsStyleName) {
    // Wrap list item in @style(style: X) block
    lines.push(`${ctx.indent}@style(style: ${styleId})`);
    const childCtx = indentContext(ctx);
    const contentLines = content.split("\n");
    lines.push(`${childCtx.indent}${prefix}${contentLines[0] ?? ""}`);
    const continuationIndent = childCtx.indent + " ".repeat(prefix.length);
    for (let i = 1; i < contentLines.length; i++) {
      lines.push(`${continuationIndent}${contentLines[i]}`);
    }
  } else {
    // Normal list item
    const contentLines = content.split("\n");
    lines.push(`${ctx.indent}${prefix}${contentLines[0] ?? ""}`);
    const continuationIndent = ctx.indent + " ".repeat(prefix.length);
    for (let i = 1; i < contentLines.length; i++) {
      lines.push(`${continuationIndent}${contentLines[i]}`);
    }
  }

  return lines;
}

/**
 * Check if a styleId is a structural style that's handled elsewhere.
 */
function isStructuralStyle(styleId: string): boolean {
  // Headings are handled by heading emission
  if (/^Heading[1-6]$/i.test(styleId)) return true;
  // Normal is the default, no need to emit
  if (styleId === "Normal") return true;
  // ListParagraph is handled by list emission
  if (styleId === "ListParagraph") return true;
  // TOC styles are usually auto-generated
  if (/^toc[1-9]$/i.test(styleId)) return true;
  return false;
}

/**
 * Emit a normal (non-heading, non-list, non-empty) paragraph.
 */
function emitNormalParagraph(para: SemanticParagraph, ctx: EmissionContext): string[] {
  const lines: string[] = [];

  // Emit anchors first
  lines.push(...emitAnchors(para.anchors, ctx));

  const content = emitInlineContent(para.extracted.content, ctx);

  // Check for named style that needs to be preserved
  const styleId = para.extracted.styleId;
  const needsStyleName = styleId && !isStructuralStyle(styleId);

  // Collect all style attributes (including named style if needed)
  const styleAttrs: Record<string, string> = { ...(para.styleAttrs ?? {}) };
  if (needsStyleName) {
    styleAttrs.style = styleId;
  }
  if (para.alignment) {
    styleAttrs.align = para.alignment;
  }
  const hasStyleAttrs = Object.keys(styleAttrs).length > 0;

  // Handle single indented paragraph when emitIndent is enabled
  if (ctx.emitIndent && para.indentLeftTwips > 0) {
    const len = formatTwipsAsPt(para.indentLeftTwips);
    
    // Check if we need nested style attrs
    if (hasStyleAttrs) {
      lines.push(`${ctx.indent}@indent(length: ${len})`);
      const childCtx = indentContext(ctx);
      lines.push(`${childCtx.indent}@style(${formatStyleAttrs(styleAttrs)})`);
      const innerCtx = indentContext(childCtx);
      for (const line of content.split("\n")) {
        lines.push(`${innerCtx.indent}${line}`);
      }
      return lines;
    }
    
    // Simple inline form: @indent(length: X): content
    lines.push(`${ctx.indent}@indent(length: ${len}): ${content}`);
    return lines;
  }

  // Handle style attributes (including alignment and named style)
  if (hasStyleAttrs && !para.isEmpty) {
    lines.push(`${ctx.indent}@style(${formatStyleAttrs(styleAttrs)})`);
    const childCtx = indentContext(ctx);
    for (const line of content.split("\n")) {
      lines.push(`${childCtx.indent}${line}`);
    }
    return lines;
  }

  // Simple paragraph - split on newlines and indent each
  for (const line of content.split("\n")) {
    lines.push(`${ctx.indent}${line}`);
  }

  return lines;
}

/**
 * Emit an empty paragraph as @empty directive.
 * If the empty paragraph has a named style, wraps in @style(style: X).
 */
function emitEmptyParagraph(para: SemanticParagraph, ctx: EmissionContext): string[] {
  const lines: string[] = [];

  // Emit anchors first
  lines.push(...emitAnchors(para.anchors, ctx));

  // Check for named style that needs to be preserved
  const styleId = para.extracted.styleId;
  const needsStyleName = styleId && !isStructuralStyle(styleId);

  if (needsStyleName) {
    lines.push(`${ctx.indent}@style(style: ${styleId})`);
    const childCtx = indentContext(ctx);
    lines.push(`${childCtx.indent}@empty`);
  } else {
    lines.push(`${ctx.indent}@empty`);
  }

  return lines;
}

/**
 * Emit a page break.
 */
function emitPageBreak(para: SemanticParagraph, ctx: EmissionContext): string[] {
  const lines: string[] = [];

  // Emit anchors first
  lines.push(...emitAnchors(para.anchors, ctx));

  lines.push(`${ctx.indent}@pagebreak`);

  return lines;
}

/**
 * Emit a semantic paragraph.
 */
export function emitParagraph(para: SemanticParagraph, ctx: EmissionContext): string[] {
  switch (para.kind) {
    case "heading":
      return emitHeading(para, ctx);
    case "list":
      return emitListItem(para, ctx);
    case "empty":
      return emitEmptyParagraph(para, ctx);
    case "pageBreak":
      return emitPageBreak(para, ctx);
    case "normal":
    default:
      return emitNormalParagraph(para, ctx);
  }
}

/**
 * Emit a spacing group.
 */
function emitSpacingGroup(group: SemanticGroup, ctx: EmissionContext): string[] {
  const attrs = group.attrs as SpacingGroupAttrs;
  const lines: string[] = [];

  const styleStr = formatStyleAttrs({}, attrs);
  lines.push(`${ctx.indent}@style(${styleStr})`);

  const childCtx = indentContext(ctx);
  lines.push(...emitNodes(group.children, childCtx));

  return lines;
}

/**
 * Emit an alignment group.
 */
function emitAlignmentGroup(group: SemanticGroup, ctx: EmissionContext): string[] {
  const attrs = group.attrs as AlignmentGroupAttrs;
  const lines: string[] = [];

  lines.push(`${ctx.indent}@style(align: ${attrs.alignment})`);

  const childCtx = indentContext(ctx);
  lines.push(...emitNodes(group.children, childCtx));

  return lines;
}

/**
 * Emit an indent group.
 */
function emitIndentGroup(group: SemanticGroup, ctx: EmissionContext): string[] {
  const attrs = group.attrs as IndentGroupAttrs;
  const lines: string[] = [];

  const len = formatTwipsAsPt(attrs.indentTwips);
  lines.push(`${ctx.indent}@indent(length: ${len})`);

  const childCtx = indentContext(ctx);
  lines.push(...emitNodes(group.children, childCtx));

  return lines;
}

/**
 * Emit a group node.
 */
export function emitGroup(group: SemanticGroup, ctx: EmissionContext): string[] {
  switch (group.groupKind) {
    case "spacing":
      return emitSpacingGroup(group, ctx);
    case "alignment":
      return emitAlignmentGroup(group, ctx);
    case "indent":
      return emitIndentGroup(group, ctx);
    default:
      // Fallback: emit children directly
      const lines: string[] = [];
      for (const child of group.children) {
        lines.push(...emitNode(child, ctx));
      }
      return lines;
  }
}

/**
 * Emit any semantic node.
 */
export function emitNode(node: SemanticNode, ctx: EmissionContext): string[] {
  if (isParagraph(node)) {
    return emitParagraph(node, ctx);
  }
  if (isTable(node)) {
    return emitTable(node.extracted, ctx);
  }
  if (isGroup(node)) {
    return emitGroup(node, ctx);
  }
  return [];
}

/**
 * Emit an array of semantic nodes with blank-line separators for readability.
 * Empty paragraphs are explicit @empty directives, so separators are simple.
 */
export function emitNodes(nodes: SemanticNode[], ctx: EmissionContext): string[] {
  const lines: string[] = [];
  for (let i = 0; i < nodes.length; i++) {
    lines.push(...emitNode(nodes[i]!, ctx));

    // Blank line separator between nodes for readability
    if (i < nodes.length - 1) {
      lines.push("");
    }
  }
  return lines;
}
